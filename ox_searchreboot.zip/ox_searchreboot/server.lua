CreateThread(function()
    local interval = Config.ResetInterval or (2 * 60 * 60 * 1000)

    if interval <= 0 then
        print('[ox_searchreboot] Disabled: Config.ResetInterval is 0 or lower.')
        return
    end

    print(('[ox_searchreboot] Scheduled ox_search reset every %s ms.'):format(interval))

    while true do
        Wait(interval)
        TriggerEvent(Config.ResetEvent or 'ox_search:server:resetLoot', 'ox_searchreboot')
    end
end)
