fx_version 'cerulean'
game 'gta5'
lua54 'yes'

description 'Scheduled reset helper for ox_search'

shared_script 'config.lua'
server_script 'server.lua'

dependency 'ox_search'
