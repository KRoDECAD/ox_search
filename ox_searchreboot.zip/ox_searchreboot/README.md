# ox_searchreboot

Small helper resource that resets `ox_search` loot on a timer.

It does not stop or restart `ox_search`; it only triggers:

```lua
TriggerEvent('ox_search:server:resetLoot', 'ox_searchreboot')
```

Configure the interval in `config.lua`:

```lua
Config.ResetInterval = 2 * 60 * 60 * 1000
```

Set `Config.ResetInterval = 0` to disable automatic reset.
