fx_version 'cerulean'
game 'gta5'
lua54 'yes'

description 'Open-source prop search loot system for ox_target and ox_inventory'

shared_scripts {
    '@ox_lib/init.lua',
    'config.lua'
}

client_script 'client/main.lua'
server_script 'server/main.lua'

dependencies {
    'ox_lib',
    'ox_target',
    'ox_inventory'
}
