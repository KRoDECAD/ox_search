# ox_search

Open-source replacement for prop search loot systems using `ox_target`, `ox_inventory`, and `ox_lib`.

## Features

- Search any configured GTA or addon prop model through `ox_target`.
- Server-synced loot state: all players share the same loot result for the same prop position until reset.
- Unique loot roll per searchable prop per reset cycle.
- Reopen an already searched prop if its stash still contains items.
- Configurable loot categories, item chance, count range, slots, weight, and weapon durability.
- No client polling loop; targeting is handled by `ox_target`.
- Reset loot manually with `ox_search_reset` or automatically with `ox_searchreboot`.

## Dependencies

- `ox_lib`
- `ox_target`
- `ox_inventory`
- ESX is supported through `ox_inventory` configured for ESX.

## Configuration

Edit `config.lua`.

Add a searchable category:

```lua
Config.Search.Military = {
    label = 'Military',
    slots = 8,
    maxWeight = 15000,
    emptyLootProbability = 0.4,
    randomWeaponDurability = true,
    items = {
        { item = 'ammo-9', min = 1, max = 3, probability = 0.12 },
        { item = 'WEAPON_PISTOL', min = 1, max = 1, probability = 0.02 },
    }
}
```

Add GTA or addon props to that category:

```lua
Config.PropModels.Military = {
    'prop_box_wood07a',
    'my_addon_prop_name',
    123456789
}
```

## Reset

Manual reset:

```cfg
ox_search_reset
```

Give admins permission:

```cfg
add_ace group.admin ox_search.reset allow
```

Automatic reset is handled by `ox_searchreboot/config.lua`:

```lua
Config.ResetInterval = 2 * 60 * 60 * 1000
```

## Notes

This resource opens loot with `exports.ox_inventory:openInventory('stash', stashId)`.
It does not open temporary loot as a `drop`, preventing `ox_inventory` invalid inventory type kicks.
