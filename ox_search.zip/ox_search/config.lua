Config = {}

Config.Search = {
    Common = {
        label = 'Common',
        slots = 10,
        maxWeight = 10000,
        emptyLootProbability = 0.2,
        randomWeaponDurability = true,
        minDurability = nil,
        maxDurability = nil,
        items = {
            { item = 'burger', min = 1, max = 2, probability = 0.10 },
            { item = 'water', min = 1, max = 2, probability = 0.03 },
            { item = 'bandage', min = 1, max = 2, probability = 0.01 },
            { item = 'medikit', min = 1, max = 1, probability = 0.005 },
            { item = 'ammo-9', min = 1, max = 2, probability = 0.01 },
            { item = 'WEAPON_PISTOL', min = 1, max = 1, probability = 0.005 },
        }
    },

    Rare = {
        label = 'Rare',
        slots = 5,
        maxWeight = 5000,
        emptyLootProbability = nil,
        randomWeaponDurability = false,
        minDurability = 30,
        maxDurability = 70,
        items = {
            { item = 'WEAPON_PISTOL', min = 1, max = 1, probability = 0.1 },
            { item = 'money', min = 50, max = 200, probability = 0.05 },
            { item = 'weed', min = 1, max = 3, probability = 0.03 },
        }
    }
}

Config.PropModels = {
    Common = {
        'prop_rub_trukwreck_1',
        'prop_rub_trukwreck_2',
        'prop_rub_carwreck_2',
        'prop_rub_carwreck_3',
        'prop_rub_carwreck_5',
        'prop_rub_carwreck_7',
        'prop_rub_carwreck_8',
        'prop_rub_carwreck_9',
        'prop_rub_carwreck_10',
        'prop_rub_carwreck_11',
        'prop_rub_carwreck_12',
        'prop_rub_carwreck_13',
        'prop_rub_carwreck_14',
        'prop_rub_carwreck_15',
        'prop_rub_carwreck_16',
        'prop_rub_carwreck_17',
        'prop_rub_buswreck_01',
        'prop_rub_buswreck_03',
        'prop_rub_buswreck_06',
        'cs4_05_buswreck',
        'prop_dumpster_01a',
        'prop_dumpster_02a',
        'prop_dumpster_02b',
        'prop_dumpster_3a',
        'prop_dumpster_4a',
        'prop_dumpster_4b',
        'prop_rub_boxpile_06',
        'prop_rub_boxpile_09',
        'prop_box_tea01a',
        'prop_flattruck_01d',
        'prop_skid_trolley_2',
        'prop_rub_boxpile_04',
        'prop_box_wood03a',
        'prop_box_wood04a',
        'prop_homeles_shelter_01',
        'prop_homeles_shelter_02',
        'prop_rub_boxpile_07',
        'prop_rub_boxpile_05',
    },

    Rare = {
        'prop_truktrailer_01a',
        'prop_tanktrailer_01a',
        'prop_rub_cont_01b',
        'sf_prop_sf_swift2_01a',
        'prop_rail_boxcar4',
        'prop_boxpile_05a',
        'prop_boxpile_06a',
        'prop_air_cargo_01c',
        'prop_air_cargo_01a',
        'prop_air_cargo_01b',
        'prop_air_cargo_02a',
        'prop_air_cargo_02b',
        'prop_air_cargo_03a',
        'prop_air_cargo_04a',
        'prop_air_cargo_04b',
        'prop_air_cargo_04c',
        'apa_mp_apa_crashed_usaf_01a',
        'prop_boxpile_08a',
        'prop_boxpile_02b',
        'prop_container_05a',
        'hei_prop_carrier_cargo_04b',
        'hei_prop_carrier_cargo_02a',
        'prop_shamal_crash',
        'prop_box_wood07a',
        'prop_air_trailer_1c',
        'prop_air_trailer_1a',
        'prop_boxpile_06b',
        'prop_boxpile_04a',
        'h4_prop_h4_boxpile_01b',
        'prop_boxpile_01a',
        'prop_boxpile_07a',
        'prop_boxpile_03a',
        'prop_boxpile_10b',
        'h4_prop_h4_boxpile_01a',
        'prop_boxpile_10a',
        'prop_rub_boxpile_03',
        'prop_boxpile_02d',
        'v_27_boxpile1',
    }
}

Config.SearchOptions = {
    label = 'Search',
    icon = 'fa-regular fa-hand',
    distance = 2.0,
    errorMessage = "You can't search inside a vehicle !",
    errorMessageType = 'error',
    errorMessagePosition = 'top',
    errorMessageDuration = 7000,
    errorMessage2 = 'Entity does not exist',
    errorMessage2Type = 'error',
    errorMessage2Position = 'top',
    errorMessage2Duration = 7000,
}

Config.SearchDuration = 1800
Config.RespawnSeconds = 2 * 60 * 60
Config.PlayerCooldownSeconds = 2
Config.AllowReopenWhenItemsRemain = true
Config.MarkEmptySearches = true
Config.Debug = false
