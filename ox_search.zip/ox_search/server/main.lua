local searched = {}
local playerCooldowns = {}
local tempStashes = {}

local function debugPrint(...)
    if Config.Debug then
        lib.print.info('[ox_search]', ...)
    end
end

local function modelHash(model)
    return type(model) == 'number' and model or joaat(model)
end

local function getRespawnSeconds()
    local value = Config.RespawnSeconds

    if type(value) == 'number' and value > 0 then
        return value
    end

    return 2 * 60 * 60
end

local function getPlayerCooldownSeconds()
    local value = Config.PlayerCooldownSeconds

    if type(value) == 'number' and value >= 0 then
        return value
    end

    return 2
end

local function toCoords(coords)
    if type(coords) == 'vector3' then return coords end
    if type(coords) ~= 'table' then return end

    local x = tonumber(coords.x or coords[1])
    local y = tonumber(coords.y or coords[2])
    local z = tonumber(coords.z or coords[3])

    if not x or not y or not z then return end

    return vector3(x, y, z)
end

local function roundCoord(value)
    return math.floor((value * 10) + 0.5) / 10
end

local function searchKey(searchType, model, coords)
    return ('%s:%s:%.1f:%.1f:%.1f'):format(searchType, model, roundCoord(coords.x), roundCoord(coords.y), roundCoord(coords.z))
end

local function hasModel(searchType, model)
    local models = Config.PropModels and Config.PropModels[searchType]
    if not models then return false end

    local hash = modelHash(model)

    for i = 1, #models do
        if modelHash(models[i]) == hash then
            return true
        end
    end

    return false
end

local function probabilityRoll(probability)
    if probability == nil then return true end

    probability = tonumber(probability)
    if not probability or probability <= 0 then return false end

    if probability <= 1 then
        return math.random() <= probability
    end

    return math.random(1, 100) <= probability
end

local function randomCount(item)
    local min = tonumber(item.min) or tonumber(item[2]) or 1
    local max = tonumber(item.max) or tonumber(item[3]) or min

    if max < min then
        min, max = max, min
    end

    return math.random(min, max)
end

local function weaponMetadata(searchConfig, itemName)
    if type(itemName) ~= 'string' or not itemName:find('^WEAPON_') then return end

    local metadata = {}
    local min = tonumber(searchConfig.minDurability)
    local max = tonumber(searchConfig.maxDurability)

    if searchConfig.randomWeaponDurability then
        min = min or 1
        max = max or 100
    elseif not min and not max then
        return metadata
    else
        min = min or max or 100
        max = max or min
    end

    if max < min then
        min, max = max, min
    end

    metadata.durability = math.random(min, max)

    return metadata
end

local function generateLoot(searchType)
    local searchConfig = Config.Search and Config.Search[searchType]
    if not searchConfig then return end

    local emptyProbability = searchConfig.emptyLootProbability

    if emptyProbability == nil then
        emptyProbability = 0.5
    end

    if probabilityRoll(emptyProbability) then
        return {}
    end

    local generated = {}
    local items = searchConfig.items or {}

    for i = 1, #items do
        local item = items[i]
        local name = item.item or item.name or item[1]

        if name and probabilityRoll(item.probability or item.chance) then
            local count = randomCount(item)

            if count > 0 then
                generated[#generated + 1] = {
                    name,
                    count,
                    weaponMetadata(searchConfig, name) or item.metadata or {}
                }
            end
        end
    end

    return generated
end

local function removeTempStash(stashId)
    if not stashId then return end

    pcall(function()
        exports.ox_inventory:RemoveInventory(stashId)
    end)
end

local function inventoryHasItems(stashId)
    if not stashId then return false end

    local inventory = exports.ox_inventory:GetInventory(stashId)
    local items = inventory and inventory.items

    if type(items) ~= 'table' then return false end

    for _, item in pairs(items) do
        if item and item.name and (item.count or 0) > 0 then
            return true
        end
    end

    return false
end

local function resetLoot(reason)
    for key, data in pairs(searched) do
        removeTempStash(data.stashId)
        searched[key] = nil
    end

    table.wipe(tempStashes)
    table.wipe(playerCooldowns)

    lib.print.info(('[ox_search] loot reset (%s)'):format(reason or 'manual'))
end

local function createSearchStash(searchType, searchConfig, coords, loot)
    return exports.ox_inventory:CreateTemporaryStash({
        label = searchConfig.label or searchType,
        slots = searchConfig.slots or 10,
        maxWeight = searchConfig.maxWeight or 10000,
        items = loot,
        coords = coords,
        owner = false
    })
end

lib.callback.register('ox_search:server:search', function(source, data)
    if type(data) ~= 'table' then
        return { status = 'error', message = 'Invalid search request.' }
    end

    local searchType = data.searchType
    local searchConfig = type(searchType) == 'string' and Config.Search and Config.Search[searchType]

    if not searchConfig then
        return { status = 'error', message = 'Invalid search type.' }
    end

    local model = tonumber(data.model)

    if not model or not hasModel(searchType, model) then
        return { status = 'error', message = 'This object cannot be searched.' }
    end

    local coords = toCoords(data.coords)

    if not coords then
        return { status = 'error', message = 'Invalid search position.' }
    end

    local now = os.time()
    local cooldown = playerCooldowns[source]

    if cooldown and cooldown > now then
        return { status = 'error', message = 'Please wait before searching again.' }
    end

    playerCooldowns[source] = now + getPlayerCooldownSeconds()

    local ped = GetPlayerPed(source)

    if not ped or ped == 0 then
        return { status = 'error', message = 'Player ped was not found.' }
    end

    local playerCoords = GetEntityCoords(ped)
    local maxDistance = ((Config.SearchOptions and Config.SearchOptions.distance) or 2.0) + 2.0

    if #(playerCoords - coords) > maxDistance then
        return { status = 'error', message = 'You are too far away to search this.' }
    end

    local key = searchKey(searchType, model, coords)
    local previous = searched[key]

    if previous then
        if previous.expiresAt > now then
            if Config.AllowReopenWhenItemsRemain ~= false and inventoryHasItems(previous.stashId) then
                debugPrint('reopened existing stash', previous.stashId)

                return {
                    status = 'ok',
                    inventory = previous.stashId
                }
            end

            return {
                status = 'already_searched',
                message = 'This has already been searched.'
            }
        end

        removeTempStash(previous.stashId)

        if previous.stashId then
            tempStashes[previous.stashId] = nil
        end

        searched[key] = nil
    end

    local loot = generateLoot(searchType)

    if not loot then
        return { status = 'error', message = 'Loot configuration is missing.' }
    end

    local expiresAt = now + getRespawnSeconds()

    if #loot == 0 then
        if Config.MarkEmptySearches ~= false then
            searched[key] = { expiresAt = expiresAt }
        end

        return {
            status = 'empty',
            message = 'Nothing useful was found.'
        }
    end

    local stashId = createSearchStash(searchType, searchConfig, coords, loot)

    if not stashId then
        return { status = 'error', message = 'Unable to create loot inventory.' }
    end

    searched[key] = {
        expiresAt = expiresAt,
        stashId = stashId
    }

    tempStashes[stashId] = key

    debugPrint('created stash', stashId, key)

    return {
        status = 'ok',
        inventory = stashId
    }
end)

AddEventHandler('ox_search:server:resetLoot', function(reason)
    resetLoot(reason or GetInvokingResource() or 'event')
end)

exports('ResetLoot', function(reason)
    resetLoot(reason or GetInvokingResource() or 'export')
end)

RegisterCommand('ox_search_reset', function(source)
    if source ~= 0 and not IsPlayerAceAllowed(source, 'ox_search.reset') then
        return
    end

    resetLoot(source == 0 and 'console' or ('player:%s'):format(source))
end, false)

AddEventHandler('playerDropped', function()
    playerCooldowns[source] = nil
end)

AddEventHandler('onResourceStop', function(resource)
    if resource ~= GetCurrentResourceName() then return end

    for stashId in pairs(tempStashes) do
        removeTempStash(stashId)
    end
end)
