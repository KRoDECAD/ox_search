Config = {}

Config.ResetInterval = 2 * 60 * 60 * 1000
Config.ResetEvent = 'ox_search:server:resetLoot'
