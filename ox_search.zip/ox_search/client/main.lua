local targetNames = {}
local searching = false

local function optionConfig()
    return Config.SearchOptions or {}
end

local function notify(description, type, id, duration)
    local options = optionConfig()

    lib.notify({
        id = id,
        type = type or 'inform',
        description = description,
        position = options.errorMessagePosition or 'top',
        duration = duration or options.errorMessageDuration or 7000
    })
end

local function modelHash(model)
    return type(model) == 'number' and model or joaat(model)
end

local function registerSearchTarget(searchType, model)
    local options = optionConfig()
    local hash = modelHash(model)
    local name = ('ox_search:%s:%s'):format(searchType, hash)

    targetNames[#targetNames + 1] = { hash = hash, name = name }

    exports.ox_target:addModel(hash, {
        name = name,
        icon = options.icon or 'fa-regular fa-hand',
        label = options.label or 'Search',
        distance = options.distance or 2.0,
        canInteract = function(entity)
            return entity
                and entity ~= 0
                and DoesEntityExist(entity)
                and not IsPedInAnyVehicle(cache.ped, false)
        end,
        onSelect = function(data)
            if searching then return end

            local entity = data and data.entity

            if not entity or entity == 0 or not DoesEntityExist(entity) then
                return notify(options.errorMessage2 or 'Entity does not exist', options.errorMessage2Type or 'error', 'ox_search_no_entity', options.errorMessage2Duration)
            end

            if IsPedInAnyVehicle(cache.ped, false) then
                return notify(options.errorMessage or "You can't search inside a vehicle !", options.errorMessageType or 'error', 'ox_search_in_vehicle')
            end

            local coords = GetEntityCoords(entity)
            local distance = #(GetEntityCoords(cache.ped) - coords)
            local maxDistance = (options.distance or 2.0) + 1.0

            if distance > maxDistance then
                return notify('You are too far away to search this.', 'error', 'ox_search_too_far')
            end

            local duration = Config.SearchDuration or options.duration or 1800
            searching = true

            if duration and duration > 0 then
                local completed = lib.progressCircle({
                    duration = duration,
                    label = options.label or 'Search',
                    position = 'bottom',
                    useWhileDead = false,
                    canCancel = true,
                    disable = {
                        car = true,
                        move = true,
                        combat = true
                    },
                    anim = {
                        dict = 'amb@prop_human_bum_bin@base',
                        clip = 'base'
                    }
                })

                if not completed then
                    searching = false
                    return
                end
            end

            local response = lib.callback.await('ox_search:server:search', false, {
                searchType = searchType,
                model = GetEntityModel(entity),
                coords = {
                    x = coords.x,
                    y = coords.y,
                    z = coords.z
                }
            })

            searching = false

            if not response then
                return notify('Search failed.', 'error', 'ox_search_failed')
            end

            if response.status == 'ok' and response.inventory then
                exports.ox_inventory:openInventory('stash', response.inventory)
                return
            end

            if response.status == 'empty' then
                return notify(response.message or 'Nothing useful was found.', 'inform', 'ox_search_empty')
            end

            if response.status == 'already_searched' then
                return notify(response.message or 'This has already been searched.', 'error', 'ox_search_already')
            end

            notify(response.message or 'Unable to search this.', 'error', 'ox_search_denied')
        end
    })
end

CreateThread(function()
    if GetResourceState('ox_target') ~= 'started' then
        return lib.print.error('[ox_search] ox_target must be started before ox_search')
    end

    if GetResourceState('ox_inventory') ~= 'started' then
        return lib.print.error('[ox_search] ox_inventory must be started before ox_search')
    end

    for searchType, models in pairs(Config.PropModels or {}) do
        for i = 1, #models do
            registerSearchTarget(searchType, models[i])
        end
    end

    lib.print.info(('[ox_search] registered %s searchable prop targets'):format(#targetNames))
end)

AddEventHandler('onResourceStop', function(resource)
    if resource ~= GetCurrentResourceName() then return end

    for i = 1, #targetNames do
        local target = targetNames[i]
        exports.ox_target:removeModel(target.hash, target.name)
    end
end)
